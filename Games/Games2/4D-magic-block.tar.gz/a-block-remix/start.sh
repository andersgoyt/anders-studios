#!/bin/bash
cd "$(dirname "$0")"
./a-block-remix